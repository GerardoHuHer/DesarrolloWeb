<?php

var_dump($_POST);
var_dump($_GET);

?>